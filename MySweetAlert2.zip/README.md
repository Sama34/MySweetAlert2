# MySweetAlert2

MySweetAlert2, a plugin for MyBB 1.8 - Replaces JQuery's jGrowl with SweetAlert2.
* Author: Skryptec
* Website: https://skryptec.net/
* Copyright: © 2014 - 2019 Skryptec

## Installation

Upload all contents to your MyBB root and install the plugin in the admin control panel.
